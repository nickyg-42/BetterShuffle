# better-shuffle
Node app that utilizes the Spotify API to randomize a users playlist of choice

HTML template thanks to: https://html5-templates.com/
